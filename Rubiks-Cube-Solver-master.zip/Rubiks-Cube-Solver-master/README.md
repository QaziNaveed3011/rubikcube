# Rubiks-Cube-Solver
- [Link](https://varunpatil.github.io/Rubiks-Cube-Solver/)
- This Solver uses F2L and a combination of beginners method steps to solve the cube
